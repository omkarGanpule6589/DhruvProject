import Swal from "sweetalert2";
import "./alert.css"

export function SuccessNotification(message) {
  Swal.fire({
    title: "",
    text: message,
    icon: "success",
    customClass:{
      popup:"success-notification",
      htmlContainer:"abcd",
    },
    confirmButtonText: "Ok",
  });
}

export function ErrorNotification(message) {
  Swal.fire({
    title: "",
    text: message,
    icon: "error",
    customClass:{
      popup:"error-notification",
      htmlContainer:"abcd",
    },
    confirmButtonText: "Ok",
  });
}
