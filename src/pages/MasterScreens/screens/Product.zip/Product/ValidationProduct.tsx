import * as Yup from "yup";

export const validation = Yup.object({
  ProductName: Yup.string().trim().required("Product is required"),
  ProductTypeId: Yup.string().trim().required("Product Type is required"),
 // ProductLine: Yup.string().trim().required("Product Line is required"),
  ProductRevision: Yup.string().trim().required("Revision is required"),
});
