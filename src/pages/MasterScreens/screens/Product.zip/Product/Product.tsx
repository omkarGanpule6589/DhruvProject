import { GridColDef, GridRowId } from "@mui/x-data-grid";
//import GridPro from "../../../../components/DataGridPro/GridPro";
import React, { useContext, useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { getProductList } from "./ProductAPI";
import MuiModules from "../../../../MUI-Module/MuiImports";
import MuiIcons from "../../../../MUI-Module/Mui-Icons";
import ConfirmDialog from "../../DeleteCommon/DeleteCnf";
import { ThemeContext } from "../../../../ContextMain";
import { Backdrop, CircularProgress } from "@mui/material";
import CheckCircleOutlineIcon from "@mui/icons-material/CheckCircleOutline";
import { ErrorHandling1 } from "../../../TransactionScreens/ErrorHandling/ErrorHandling";
import { getSessionToken } from "../../../../components/AuthUser";
import { decodeToken } from "react-jwt"; 
import { Permission } from "../AQLLevel/AQLLevelApi";
interface Productlist {
  ProductId: number;
  ProductName: string;
  ProductionRevision: string;
  ProductDescription: string;
}

const GridPro = ({ rows, columns, id, onRowClick }) => {
  return (
    <MuiModules.DataGridPro
      rows={rows}
      onRowClick={onRowClick}
      onCellClick={onRowClick}
      columns={columns}
      slots={{ toolbar: MuiModules.GridToolbar }}
      getRowId={(row) => row[id]}
      autoHeight
      pagination
      pageSizeOptions={[5, 10, 50]}
      density="compact"
      initialState={{
        pagination: { paginationModel: { pageSize: 5 } },
      }}
    />
  );
};

function Product() {
  const navigate = useNavigate();
  const [data, setData] = useState<Productlist[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [isDeleteCnfDialogOpen, setDeleteCnfDialogOpen] =
    useState<boolean>(false);
  const [deleteData, setDeleteData] = useState(null);

  const { backgroundtheme } = useContext(ThemeContext);
  const [deleteDataName, setDeleteDataName] = useState(null);
  const [gridload, setgridload] = useState(false);
  const accessToken = getSessionToken();
  const myDecodedToken = decodeToken(accessToken) as {
    Id: string;
    Email: string;
    RoleId: string;
  };
  const { Id, RoleId } = myDecodedToken;

  const [Add, setAdd] = useState(false);
  const [Read, SetRead] = useState(false);
  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await Permission(+RoleId, "Product");
        const result = response?.data?.value[0];
        const res = result?.RolePermissions[0];
        const { CanCreate, CanRead, CanEdit, CanDelete } = res;
        setAdd(CanCreate);
        SetRead(CanRead);
      } catch (error) {
        ErrorHandling1(error);
      }
    };

    fetchData();
  }, []);

  useEffect(() => {
    fetchData();
  }, []);
  const fetchData = async () => {
    setgridload(true);
    try {
      const response = await getProductList();
      const sortedData = response.data.value.sort((a, b) => {
        return a.ProductName.localeCompare(b.ProductName);
      });

      setData(sortedData);
      //setData(response.data.value);
      setError("");
    } catch (error) {
      setgridload(false);
      ErrorHandling1(error);
    }
    setgridload(false);
  };
  const baseColumns: GridColDef[] = [
    // { field: "ProductId", headerName: "ID", width: 90 },

    {
      field: "ProductName",
      headerName: "Product Name",
      width: 250,
    },
    {
      field: "ActiveRevision",
      headerName: "",
      width: 50,
      renderCell: (params) => {
        return (
          <div>
            {params.row.ActiveRevision && (
              <CheckCircleOutlineIcon
                style={{
                  fontSize: "large",
                }}
              />
            )}
          </div>
        );
      },
    },
    {
      field: "ProductRevision",
      headerName: "Revision",
      width: 150,
    },

    {
      field: "ProductDescription",
      headerName: "Product Description",
      width: 400,
    },
    // {
    //   field: "actions",
    //   headerName: "Action",
    //   type: "actions",
    //   width: 80,
    //   getActions: (params) => [
    //     <MuiModules.GridActionsCellItem
    //       icon={<MuiIcons.ReadMoreIcon />}
    //       label="Edit"
    //       //   onClick={edit(params.id, params.row)}
    //     />,
    //     // <MuiModules.GridActionsCellItem
    //     //   icon={<MuiIcons.DeleteIcon />}
    //     //   label="Delete"
    //     //   onClick={deleteCnf(params.id,params)}
    //     // />,
    //   ],
    // },
  ];


  const actionColumn: GridColDef = {
    field: "actions",
    headerName: "Action",
    type: "actions",
    width: 70,
    renderCell: (params) => (
      <MuiModules.GridActionsCellItem icon={<MuiIcons.ReadMoreIcon />} label="Edit" />
    ),
  };

  const columns = Read ? [...baseColumns, actionColumn] : baseColumns;

  const edit = React.useCallback(
    (id: GridRowId, row) => () => {
      handleEditClick(id);
    },
    []
  );

  const handleEditClick = (id) => {
    if (Read) {
    navigate(`/masterdata/productAddEdit/${id}`);
    }
  };
  const handleAddClick = () => {
    navigate("/masterdata/productAddEdit");
  };

  const deleteCnf = React.useCallback(
    (id: GridRowId, params) => () => {
      setDeleteCnfDialogOpen(true);
      setDeleteData({ id, endPoint: `odata/Product?key=${id}` });
      setDeleteDataName(params.row.ProductName);
    },
    []
  );
  const deleteDialogClose = () => {
    setDeleteCnfDialogOpen(false);
    setDeleteData(null);
  };
  const OnCallAPI = () => {
    fetchData();
  };

  return (
    <div
      className={`content ${
        backgroundtheme === "black" ? "content_Dark" : "content"
      }`}
    >
      <Backdrop className="backdrop" open={gridload}>
        <CircularProgress color="inherit" />
      </Backdrop>
      <MuiModules.UIBox sx={{ height: "300", width: "100%" }}>
        <MuiModules.UITypography component="h1" variant="h5">
          Product
        </MuiModules.UITypography>
        <br />
        <div
          style={{ display: "flex", justifyContent: "end", marginBottom: "1%" }}
        >
          {Add && (
            <MuiModules.UIButton variant="contained" onClick={handleAddClick}>
              Add
            </MuiModules.UIButton>
          )}
        </div>
        <GridPro
          id="ProductId"
          rows={data}
          columns={columns}
          onRowClick={(row) => handleEditClick(row?.id)}
        />
      </MuiModules.UIBox>
      {isDeleteCnfDialogOpen && (
        <ConfirmDialog
          isOpen={isDeleteCnfDialogOpen}
          onClose={deleteDialogClose}
          data={deleteData}
          onDelete={OnCallAPI}
          screenName="Product "
          valueName={deleteDataName}
        />
      )}
    </div>
  );
}

export default Product;
