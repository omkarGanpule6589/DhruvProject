import * as React from "react";
import CircularProgress from "@mui/material/CircularProgress";
import Box from "@mui/material/Box";

export default function CircularIndeterminate() {
  return (
    <div style={{ alignItems: "center", textAlign: "center" }}>
      <CircularProgress />
    </div>
  );
}
