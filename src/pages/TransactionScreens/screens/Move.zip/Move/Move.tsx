import MuiModules from "../../../../MUI-Module/MuiImports";
import { useFormik } from "formik";
import { useEffect, useState, useContext } from "react";
import * as Yup from "yup";
import {
  getDefectCodeGroupDetailFetch,
  getDegectCodeGroupId,
  getEquipmentlist,
  getEquipmentlistfromop,
  getGKBProductById,
  getOperationlist,

  getProcessFlowById,

  getRoutecardIdbyfilter,
  getroutecardlist,
  getroutesonorder,
  gettostep,
  postMove,
} from "./api";
import {
  ErrorNotification,
  
  SuccessNotification,
  
  SuccessNotificationforMove,
} from "../../../../components/common/AlertMessage/AlertMessage";
import React from "react";
import CircularIndeterminate from "../../Transaction/Spinnerload";
import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Autocomplete,
  Backdrop,
  Box,
  Checkbox,
  CircularProgress,
  Tooltip,
} from "@mui/material";
import { getroutecardlistmain } from "../Release/api";
import { getRoutecardIdbyName } from "../ComponentIssue/ComponentIssueAPI";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import Copyright from "../../../Copyright";
import { ThemeContext } from "../../../../ContextMain";
import ErrorHandling, {
  ErrorHandling1,
} from "../../ErrorHandling/ErrorHandling";
import DescriptionIcon from "@mui/icons-material/Description";
import InfoIcon from "@mui/icons-material/Info";
import ConfirmDialog from "../Popup/Documentcnf";
import { decodeToken } from "react-jwt";
import { getSessionToken } from "../../../../components/AuthUser";
import { Permission } from "../../../MasterScreens/screens/AQLLevel/AQLLevelApi";
import DataCollectAccor from "../DataCollection Sub-Component/DataCollectAccor";
import DataCollectAccor1 from "../DataCollection Sub-Component/DataCollectAccor1";
import WorkInfoDialog from "../Popup/WorkInstructionshow";
import { GridColDef } from "@mui/x-data-grid";
import MuiIcons from "../../../../MUI-Module/Mui-Icons";
import { getcustomerinfo, getEmployeeList, getOederinfo } from "../Inward/InwardApi";
import DataCollectionPopUp from "./DataCollectionPopUp";
import { getScanCombineRouteCradGrid } from "../Combine/CombineApi";
import { getdisAssociateRouteCad } from "../Disassociate/api";
import DataCollectAccor2 from "../DataCollection Sub-Component/DataCollectionWithoutAccordian";
import { debounce } from "lodash";
const demodata = [];

const validation = Yup.object({
 // routeCard: Yup.string().required("Enter routecard"),
  username: Yup.string().trim().required("User Name is required"),
});
interface ScanRoutecard {
  RouteCardId: number;
  RouteCardName: string;
}
interface loadEquipment {
  EquipmentId: number;
  EquipmentName: string;
}
interface loadOperation {
  OperationId: number;
  OperationName: string;
}
interface ReasonGrid {
  DefectCodeGroupEntryId: number;
 
  DefectCodeName: string;
  Qty:number;
  

  DefectCodeId:number;
  

  
}
interface ReasonGrid1 {
  DefectCodeGroupEntryId: number;
 
  DefectCodeName: string;
  
  

  
}

interface UniqueIdentification {
  UniqueId: number;
  DefectCodeId: number;
  UniqueIdentificationID: number;
  UniqueIdentification:string;
  DefectName:string;
  
}
interface UniqueIdentification1 {
 
  UniqueId: number;
  routeCardId: number;
 
   routeCardName:string;
   
   Datacollection1:Datacollection2[];
 
}

interface Datacollection2{
  id:number,

                      dataPointName: string,
                      dataPointType: string,
                      upperLimit: number,
                      lowerLimit: number,
                      isRequired: boolean,
                      defaultValue: number,
                      serialNo: number,
                      rowPosition: number,
                      columnPosition:number,
                      dataCollectionName: string,
                      dataCollectiondefID: number,
                   
}
const GridPro = ({ rows, columns, id,  }) => {

  return (
    <MuiModules.DataGridPro
      rows={rows}
     // onRowClick={onRowClick}
      //onCellClick={onRowClick}
      columns={columns}
      slots={{ toolbar: MuiModules.GridToolbar }}
      getRowId={(row) => row[id]}
      autoHeight
      
      pagination
      pageSizeOptions={[5, 10, 50]}
      density="compact"
      initialState={{
        pagination: { paginationModel: { pageSize: 10 } },
      }}
    />
  );
};
const GridPro1 = ({
  rows,
  columns,
  id,
  paginationModel,
  onPaginationModelChange,
}) => {
  return (
    <MuiModules.DataGridPro
      rows={rows}
      columns={columns}
      density="compact"
      slots={{ toolbar: MuiModules.GridToolbar }}
      autoHeight
      getRowId={id ? (row) => row[id] : undefined}
      pagination
      paginationModel={paginationModel}
      onPaginationModelChange={onPaginationModelChange}
      pageSizeOptions={[5, 30, 50]}
    />
  );
};
const Move = () => {
  // const rowData = [];
  // const [rowsDatacollection, setrowsDatacollection] = useState(rowData);
  const [Data, setData] = useState<ReasonGrid[]>([]);
  const [selecteddataId, setselecteddataId] = useState(null);
  const accessToken = getSessionToken();
  const myDecodedToken = decodeToken(accessToken) as {
    Id: string;
    Email: string;
    RoleId: string;
  };
  const { RoleId } = myDecodedToken;
  const [Execute, setExecute] = useState(false);
  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await Permission(+RoleId, "MoveService");
        const result = response?.data?.value[0];
        const res = result?.RolePermissions[0];
        const { CanExecute } = res;
        setExecute(CanExecute);
      } catch (error) {
        ErrorHandling1(error);
      }
    };

    fetchData();
  }, []);
  const { backgroundtheme } = useContext(ThemeContext);
  const [isDocOpen, setisDocOpen] = useState<boolean>(false);
  const [deleteData, setDeleteData] = useState(null);
  const docclose = () => {
    setisDocOpen(false);
  };
  const [isWorkinfoOpen, setisWorkinfoOpen] = useState<boolean>(false);
  const WorkinfoClose = () => {
    setisWorkinfoOpen(false);
  };
  const [submitspinnerL, setsubmitspinnerL] = useState(false);
  const [disable, setdisable] = useState(true);
  const [Inrework, setInrework] = useState(false);
  const [spinnerL, setSpinnerL] = useState(true);
  const [open, setOpen] = React.useState(false);
  const [Equipment, setEquipment] = useState<string | null>("");
  const [msg, setMsg] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [DefectReason, setDefectReason] = useState<
  ReasonGrid[]
    >([]);

  const Initailrows = [];
  const [Data1,setData1 ] = useState<UniqueIdentification[]>([]);

  const [Data2,setData2 ] = useState<UniqueIdentification1[]>([]);
  const [paginationModel, setPaginationModel] = useState({
    page: 0,
    pageSize: 5,
  });
  const [ChildCount, setChildCount] = useState(false);
  const [open1, setopen1] = useState(false);
  const [selectedRow, setSelectedRow] = useState(null);
  const [isoldrow, setoldrow] = useState(true);
  const [isAccordionExpanded, setIsAccordionExpanded] = useState(false);
  const [isAccordionExpanded1, setIsAccordionExpanded1] = useState(false);
  const [isUsernameValid, setIsUsernameValid] = React.useState(true);

  const initialValues = {
    Routecard: "",
    Equipment: "",
    Status: "",
    Comments: "",
    RoutecardId: "",
    username:"",
    EquipmentId: "",
    EmployeeId:null,
    ToStep: "",
    ToStepId: "",
    Defects:false
  };
  const {
    values,
    errors,
    touched,
     handleBlur,
    handleChange,
    handleSubmit,
    handleReset,
    setFieldValue,
  } = useFormik({
    initialValues,
    validationSchema: validation,
    onSubmit: (values, action) => {
      handlepostsave(event,action);
    },
  });
  const debouncedFetchUserdata = debounce(async (username) => {
    await fetcUserdata2(username);
  }, 300);
  const fetcUserdata2 = async (username) => {
   // setSpinnerL(false);
  
    const Employename = username.trim();
    if (Employename === "") {
      setIsUsernameValid(true);
    //  setSpinnerL(true);
      return;
    }
  
    try {
      const response = await getEmployeeList();
      if (response.data?.value[0]) {
        const result = response.data.value;
        const employeeData = result.find(
          (employee) =>
            employee.EmployeeName &&
            employee.EmployeeName.trim().toLowerCase() === username.toLowerCase()
        );
        if (employeeData) {
          setFieldValue("EmployeeId", employeeData?.EmployeeId);
          setIsUsernameValid(true);
        } else {
          setFieldValue("EmployeeId", null);
          setIsUsernameValid(false);
        }
      } else {
        setFieldValue("EmployeeId", null);
        setIsUsernameValid(false);
      }
    //  setSpinnerL(true);
    } catch (error) {
      setFieldValue("EmployeeId", null);
      setIsUsernameValid(false);
      if (error.response?.status === 401) {
        ErrorNotification("Session expired, Please login again");
      } else {
        ErrorNotification(error.response?.data?.errors?.[0] || error.message);
      }
     // setSpinnerL(true);
    }
  };
  const handleUsernameChange = (e) => {
    const { value } = e.target;
    handleChange(e); // Update Formik's state
    debouncedFetchUserdata(value); // Trigger the debounced fetch
  }; // Adjust the debounce delay as needed (300ms here)
 // const debouncedFetchUserdata = debounce(fetcUserdata, 300);
  const handlepostsave = async (event,{setSubmitting}) => {
    
  
 
    if (!isUsernameValid) {
     // ErrorNotification("Please fix errors before submitting.");
      setSubmitting(false);
      return; // Stop submission
    }
    setsubmitspinnerL(true);
    // const transformedObject = rows.reduce((acc, curr) => {
    //   if (curr.dataPointType !== "boolean") {
    //     acc[curr.dataPointName] = curr.defaultValue;
    //   } else {
    //     acc[curr.dataPointName] = curr.defaultValue || "false";
    //   }
    //   return acc;
    // }, {});
    function transformDataPoints(datacollcetiondata, selecteddataId) {
    
      let defId;
      const names = new Set(datacollcetiondata.map(item => item.dataCollectionName));
      
      if (names.size === 1) {
          defId = datacollcetiondata[0].dataCollectiondefID;
      } else if (names.size === 0) {
          defId = null;
      } else {
          defId = selecteddataId || null;
      }
  
      const newmodrows = defId ? datacollcetiondata.filter(item => item.dataCollectiondefID === defId) : [];
  
      return newmodrows.reduce((acc, curr) => {
          acc[curr.dataPointName] = curr.dataPointType !== "boolean" 
              ? curr.defaultValue 
              : (curr.defaultValue || "false");
          return acc;
      }, {});
  }
    let defId;
    const names = new Set(rows.map((item) => item.dataCollectionName));
    if (names.size === 1) {
      defId = rows[0].dataCollectiondefID;
    }
    if (names.size === 0) {
      defId = null;
    }
    if (names.size > 1) {
      if (selecteddataId) {
        defId = selecteddataId;
      } else {
        defId = null;
      }
    }
    let newmodrows;
    if (defId) {
      newmodrows = rows.filter((item) => item.dataCollectiondefID === defId);
    }
    let transformedObject = {};
    if (newmodrows) {
      transformedObject = newmodrows.reduce((acc, curr) => {
        if (curr.dataPointType !== "boolean") {
          acc[curr.dataPointName] = curr.defaultValue;
        } else {
          acc[curr.dataPointName] = curr.defaultValue || "false";
        }
        return acc;
      }, {});
    } else {
      transformedObject = {};
    }
    const ReasonDefectList = Data
  .filter(row => row.Qty !== undefined && row.Qty !== null && String(row.Qty).trim() !== "" && row.Qty > 0) // filter out rows with invalid or non-positive Qty
  .map(row => ({
    ReasonName: row.DefectCodeName,
    Qty: Number(row.Qty), // Convert Qty to a number
  }));

  
  const ChildDataCollectionList = Data2
  .filter(row => row.routeCardId !== null && row.routeCardName !== null ) // filter out rows with invalid or non-positive Qty
  .map(row => ({
    RouteCardName:row.routeCardName,
   
      RouteCardId:  row.routeCardId,
      DataCollectionDefId: row.Datacollection1.length > 0 ? row.Datacollection1[0].dataCollectiondefID : null,
      DataPoints: transformDataPoints(row.Datacollection1, selecteddataId) 
  }));
  const UniqueIdentifyChildRouteCards = Data1
  .filter(row => row.UniqueIdentificationID !== null && row.UniqueIdentification !== null && String(row.UniqueIdentification).trim() !== "" && row.DefectName !== null||"" ) // filter out rows with invalid or non-positive Qty
  .map(row => ({
    ReasonName: row.DefectName,
    RouteCardId:  row.UniqueIdentificationID,
    RouteCardName:row.UniqueIdentification
  }));
//   const UniqueIdentifyChildRouteCards1 = UniqueIdentifyChildRouteCards.map(equipmentGroup => ({
//     RouteCardId: equipmentGroup.RouteCardId,
//     ReasonName:equipmentGroup.ReasonName,
//     DataCollectionDefId: equipmentGroup.Datacollection1.length > 0 ? equipmentGroup.Datacollection1[0].dataCollectiondefID : null,
//     DataPoints: transformDataPoints(equipmentGroup.Datacollection1, selecteddataId) // Assuming selecteddataId is defined
// }));
  
    
   
    const body = {
      RouteCardId: values.RoutecardId,
     Comment: values.Comments,
      EquipmentId: values.EquipmentId,
      ToStep: values.ToStepId,
      UserId:values.EmployeeId,
      IsDefectIdentified:values.Defects,
      ReasonDefectList: ReasonDefectList,
      TxnName: "MoveNext",
     
      DataPoints: transformedObject,
        DataCollectionDefId: defId,
      
        UniqueIdentifyChildRouteCards:UniqueIdentifyChildRouteCards,
        ChildDataCollectionList:ChildDataCollectionList
    
    };
    debugger

    if (!!values.Routecard) {
      // if (Equipment === null || Equipment === "" || Equipment === undefined) {
      //   setholdreamsgMsg("Equipment is Required");
      // } else {
      
      try {
        const response = await postMove(body);
        
        if (response.data) {
          const { message, htmlCode } = response.data;
          //alert(message);
          if (message.includes("|")) {
            // If the message contains a delimiter, pass it to SuccessNotificationforMove
            SuccessNotificationforMove(message);
        } else {
            // Otherwise, pass it to normal SuccessNotificationf
            SuccessNotification(message);
        }
        //  SuccessNotificationforMove(message);
          setsubmitspinnerL(false);
          handleReset(event);
          handlereset1();
          if (htmlCode) {
            const newTab = window.open();
            newTab.document.open();
            const htmlContent = `
              <!DOCTYPE html>
              <html lang="en">
              <head>
                  <meta charset="UTF-8">
                  <meta name="viewport" content="width=device-width, initial-scale=1.0">
                  <title>${values.Routecard}</title>
              </head>
              <body>
                  ${htmlCode}
              </body>
              </html>`;
            newTab.document.write(htmlContent);
            newTab.document.close();
          }

          setError("");
        }
      } catch (error2) {
        
        setsubmitspinnerL(false);
        ErrorHandling(error2);
        // if (error2.response.status === 401) {
        //   ErrorNotification("Session expired,Please login again");
        // } else {
        //   ErrorNotification(error2.response.data.errors[0]);
        // }
        //console.error("Error fetching data:", error);
        //setError("Error fetching data. Please check console for details.");
      }
      //}
    } else {
      ErrorNotification("Select the RouteCard");
    }
  };
  // const handleBlur = () => {
  //   console.log("customised handleblur worked");
  // };

  const handleEquipment = (event, newValue) => {
    setEquipment(newValue);
  };
  const [routecarddata, setroutecarddata] = useState<ScanRoutecard[]>([]);
  const [loadholdreasondata, setloadholdreason] = useState<loadEquipment[]>([]);
  const [loadequipdata, setloadequipdata] = useState<loadEquipment[]>([]);
  const [productname, setproductname] = useState<string | null>(null);
  
  const [productid, setproductid] = useState<string | null>(null);
  const [productionordername, setproductionordername] = useState<string | null>(
    null
  );
  const [qty, setqty] = useState<string | null>(null);
  const [factoryname, setfactoryname] = useState<string | null>(null);
  const [uomname, setuomname] = useState<string | null>(null);
  const [operationname, setoperationname] = useState<string | null>(null);
  const [operationId, setoperationId] = useState<string | null>(null);
  const [productrevname, setproductrevname] = useState<string | null>(null);
  const [holdreamsg, setholdreamsgMsg] = useState("");
  const [statusnum, setstatusnum] = useState<number | null>(null);
  const [loadoperationdata, setloadoperationdata] = useState<loadOperation[]>(
    []
  );
  const [proflowname, setproflowname] = useState<string | null>(null);
  const [proflowrevname, setproflowrevname] = useState<string | null>(null);
  const [tostepdata, settostepdata] = useState([]);
  const rowData = [];
  const [rows, setrows] = useState(rowData);

  const [OrderShortageQty, setOrderShortageQty] = useState<string | null>(null);
  const [OrderWIPQty, setOrderWIPQty] = useState<string | null>(null);
  const [sequencecount, setsequencecount] = useState<string | null>(null);
  const [Maxsequencecount, setMaxsequencecount] = useState<string | null>(null);

  const [base, setbase] = useState<string | null>(null);
  const [addition, setaddition] = useState<string | null>(null);
  const [side, setside] = useState<string | null>(null);
  
  useEffect(() => {
    fetchroutecardData();
    fetchHoldreasondataData();
    fetchopearationData();
  }, []);
  const fetchroutecardData = async () => {
    try {
      const response = await getroutecardlist();
      setroutecarddata(response.data.value);
      setError("");
      setOpen(true);
    } catch (error) {
      console.error("Error fetching data:", error);

      // setError("Error fetching data. Please check console for details.");
    }
  };
  const fetchHoldreasondataData = async () => {
    try {
      const response = await getEquipmentlist();
      setloadholdreason(response.data.value);
      setError("");
    } catch (error) {
      console.error("Error fetching data:", error);

      //setError("Error fetching data. Please check console for details.");
    }
  };
  const fetcheQUIPMENT = async () => {
    try {
      const response = await getEquipmentlist();
      setloadequipdata(response.data.value);
      setError("");
    } catch (error) {
      console.error("Error fetching data:", error);

      //setError("Error fetching data. Please check console for details.");
    }
  };
  const fetchopdatafromequipmentgroup = async (OpId) => {
    try {
      const response = await getEquipmentlistfromop(+OpId);
      const res = response.data.value[0].EquipmentGroup?.EquipmentGroupEntries;
      if (res) {
        const equipmentList = res
        .filter(entry => entry?.Equipment?.IsDeleted!=true) // Filter out deleted entries
        .map(entry => entry.Equipment) // Get the Equipment object from each entry
        .filter(equipment => equipment);
         
            setloadequipdata(equipmentList);
        
      } else {
       
        fetcheQUIPMENT();
        
      }

      setError("");
    } catch (error) {
      setloadequipdata([]);
      console.error("Error fetching data:", error);

      //setError("Error fetching data. Please check console for details.");
    }
  };
  const fetchopearationData = async () => {
    try {
      const response = await getOperationlist();
      setloadoperationdata(response.data.value);
      setError("");
    } catch (error) {
      console.error("Error fetching data:", error);
      setloadholdreason(error);
      //setError("Error fetching data. Please check console for details.");
    }
  };
  const handleHoldReason = (event, newValue) => {
    setEquipment(newValue);
    if (!newValue) {
      setFieldValue("EquipmentId", null);
    }
    const HoldreaId = loadholdreasondata.find((r) =>
      r.EquipmentName === newValue ? r.EquipmentId : null
    );
    const { EquipmentId } = HoldreaId;
    setFieldValue("EquipmentId", EquipmentId);
    setholdreamsgMsg(null);
  };
  const handlescanroutecard = async (event, newValue) => {
    setSpinnerL(false);
    setIsUsernameValid(true);
    setrows([]);
    if (newValue === null || newValue === "") {
      setproductname("");
      setproductid("");
      setproflowname("");
      setqty("");
      setproductionordername("");
      setfactoryname("");
      setuomname("");
      setFieldValue("Routecard", null);
      setFieldValue("RoutecardId", null);
      setproductrevname("");
      setEquipment(null);
      setholdreamsgMsg(null);
      setoperationname("");
      setoperationId("");
      setstatusnum(null);
      handleReset(event);
      setInrework(false);
      setFieldValue("username", "");
      setFieldValue("EmployeeId", null);
      setChildCount(false)
      setsequencecount(null)
        setMaxsequencecount(null)
        setOrderWIPQty(null)
      setData1([])
      
    } else {
      setFieldValue("Routecard", newValue);
      let res;
      try {
        const response = await getRoutecardIdbyName(newValue);
        setError("");
        res = response.data.value;
      } catch (error) {
        res = [];
        console.error("Error fetching data:", error);
      }
      if (res.length === 0) {
        ErrorNotification(`Invalid RouteCard, Please scan valid RouteCard`);
        handleReset(event);
        setproductname("");
        setproductid("");
        setproflowname("");
        setqty("");
        setproductionordername("");
        setfactoryname("");
        setuomname("");
        setFieldValue("Routecard", null);
        setFieldValue("RoutecardId", null);
        setproductrevname("");
        setEquipment(null);
        setholdreamsgMsg(null);
        setoperationname("");
        setoperationId("");
        setstatusnum(null);
        setdisable(true);
        setDeleteData(null);
        setInrework(false);
        setData1([])
        setbase(null);
        setaddition(null);
        setside(null)
        setsequencecount(null)
        setMaxsequencecount(null)
        setOrderWIPQty(null)
        setOrderShortageQty(null)
        
      } else {
        
        const { RouteCardId } = res[0];
        setFieldValue("RoutecardId", RouteCardId);
        setDeleteData(RouteCardId);
        if (RouteCardId !== null || RouteCardId !== 0) {
          const response = await getRoutecardIdbyfilter(RouteCardId);
          const result = response.data.value;
          const {
            Product,
            Qty,
            ProductionOrder,
            StartFactory,
            Uom,

            Status,
            CurrentStatus,
           
          } = result[0];
          setdisable(false);
          setInrework(CurrentStatus?.InRework);
          
         // const prodname = Product?.ProductDescription;
          // setproductname(prodname);

          setproductid(result[0].ProductId);
          const prodnamerev = Product?.ProductRevision;
          setproductrevname(prodnamerev);
          setqty(Qty);
          const ordername = ProductionOrder?.ProductionOrderName;
          setproductionordername(ordername);
          const facname = StartFactory?.FactoryName;
          setfactoryname(facname);
         // const uomname = Uom?.Uomname;
         // setuomname(uomname);
        // 
        
        setChildCount(result[0]?.ChildCount > 0);
       

       
          const eqpname = CurrentStatus?.Equipment?.EquipmentName;
          const eqpId = CurrentStatus?.Equipment?.EquipmentId;
          const proflowname =
            CurrentStatus?.ProcessflowStep?.Processflow?.ProcessflowName;
          const proflowrev =
            CurrentStatus?.ProcessflowStep?.Processflow?.ProcessflowRevision;
          setproflowname(proflowname);
          setproflowrevname(proflowrev);
          setEquipment(null);
          setFieldValue("EquipmentId", null);
          setholdreamsgMsg(null);
          setstatusnum(Status);
          setsequencecount(CurrentStatus?.ProcessflowStep?.Sequence);
          const opdeatailname =
            CurrentStatus?.OperationDetail?.OperationDetailName;
          const opdeatailrev = CurrentStatus?.OperationDetail?.Revision;
          const OperationId =
            CurrentStatus?.OperationDetail?.OperationId || null;
          setoperationId(OperationId);

          
          fetchopdatafromequipmentgroup(OperationId);
          fetchDefectCodenGroup(OperationId)
          
          loadoperationdata;
          const opdata = loadoperationdata.find((r) =>
            r.OperationId === OperationId ? r.OperationName : null
          );

          if (CurrentStatus?.EquipmentId != null) {
            setEquipment(CurrentStatus?.Equipment?.EquipmentName);
            setFieldValue("EquipmentId", CurrentStatus?.EquipmentId);
        }
          if (!!opdata) {
            const { OperationName } = opdata;
            setoperationname(OperationName || null);
            setoperationId(OperationId || null);
          } else {
            setoperationname(null);
            setoperationId(null);
          }
//           const OrderShortageQty = (ProductionOrder?.ProductionOrderQty) - (Qty);
//           const OrderShortageQtyresult = isNaN(OrderShortageQty) ? "" : OrderShortageQty.toString();
// setOrderShortageQty(OrderShortageQtyresult);
// ;
try{
           const GkbInfo = await getGKBProductById(Product?.ProductName);
                if (GkbInfo.data.value.length > 0) {
                const   GkbData=GkbInfo.data.value[0];
                
                  setproductname(GkbData?.LensType);
                  setbase(GkbData?.Base);
                  setaddition(GkbData?.Addition);
                  setside(GkbData?.LensSide?.LensSideName)
                  
                  //
                }
              }catch(error)
              {
                setSpinnerL(true);
              }
              try{
                
                const Proceesflowstepdetails1 = await getProcessFlowById(CurrentStatus?.ProcessflowStep?.Processflow?.ProcessflowId);
                     if (Proceesflowstepdetails1.data.value.length > 0) {
                      
                     const   Maxsequence=Proceesflowstepdetails1.data.value[0].ProcessflowSteps.length;
                     setMaxsequencecount(Maxsequence);
                      
                       
                       //
                     }
                   }catch(error)
                   {
                     setSpinnerL(true);
                   }
                   try{
                    
                   const ProductionOrderresponse = await getroutesonorder(ProductionOrder?.ProductionOrderId);
                         if (ProductionOrderresponse.data.value.length > 0) {
                          
                          const WIPQty = ProductionOrderresponse.data.value
                          .map(item => item.Qty)  // Extract `qty` values
                          .reduce((acc, Qty) => acc + Qty, 0); 
                          
                           setOrderWIPQty(WIPQty)
                           const OrderShortageQty = (ProductionOrder?.ProductionOrderQty) - (WIPQty);
          const OrderShortageQtyresult = isNaN(OrderShortageQty) ? "" : OrderShortageQty.toString();
setOrderShortageQty(OrderShortageQtyresult);
                           //
                         }
                       }catch(error)
                       {
                         setSpinnerL(true);
                       }

           if(ordername){
            
                        try {
                          const Productionordername1 = await getOederinfo(ordername);
                          const  Productionordername = Productionordername1.data.value;
                          const {
                          //  CustomerId,
                            Customer
                           
                          } = Productionordername[0];
                          setuomname(Customer?.CustomerName);
                          
                          // const customerinfo = await getcustomerinfo(CustomerId);
                          // const  customerinfo1 = customerinfo.data.value;
          
          
                          // setuomname(Customer?.CustomerName);
                          
                        } catch (error) {
                          
                          console.error("Error fetching data:", error);
                        }
          
                      }
          const body = {
            RoutecardId: RouteCardId,
            TxnName: "MoveNext",
          };
          const body1 = {
            RoutecardId: RouteCardId,
            TxnName: "MoveNext",
          };
          try {
            const response = await gettostep(body);
            const result = response.data.nextStepDetails;
            settostepdata(result);
            if (result.length > 0) {
              setFieldValue("ToStep", result[0].nextStepName);
              setFieldValue("ToStepId", result[0].nextStepId);
            }
            const createRow4 = (item3) => {
              return {
                id: Math.random(),

                dataPointName: item3?.dataPointName,
                dataPointType: item3?.dataPointType,
                upperLimit: item3?.lowerLimit,
                lowerLimit: item3?.upperLimit,
                isRequired: item3?.isRequired,
                defaultValue: item3?.defaultValue,
                serialNo: item3?.serialNo,
                rowPosition: item3?.rowPosition,
                columnPosition: item3?.columnPosition,
                dataCollectionName: item3?.dataCollectionName,
                dataCollectiondefID: item3?.dataCollectiondefID,
              };
            };
            
            const res1 = response?.data?.dataCollection_Details;
            if (response?.data) {
              const res = response?.data?.dataCollection_Details;
             
              if (res) {
                res.map((item) => {
                  const createRow = () => {
                    const newRow = {
                      id: Math.random(),

                      dataPointName: item.dataPointName,
                      dataPointType: item.dataPointType,
                      upperLimit: item.lowerLimit,
                      lowerLimit: item.upperLimit,
                      isRequired: item.isRequired,
                      defaultValue: item.defaultValue,
                      serialNo: item.serialNo,
                      rowPosition: item.rowPosition,
                      columnPosition: item.columnPosition,
                      dataCollectionName: item.dataCollectionName,
                      dataCollectiondefID: item.dataCollectiondefID,
                    };
                    return newRow;
                  };

                  setrows((prevRows) => [...prevRows, createRow()]);
                });
                setError("");
              }
          
            }
            
          
            const response1 = await getdisAssociateRouteCad(body1);

            const result1 = response1.data.currentlyAssociatedRouteCards;
             
            if (result1) {
              
              
              const Datacollection123 = res1?.map(createRow4);
              
             
              result1.map((item1) => {
                const createRow1 = () => {
                  const newRow2 = {
                    UniqueId: Math.random(),

                    routeCardId: item1.routeCardId,
                    routeCardName: item1.routeCardName,
                    Datacollection1: Datacollection123
                  };
                  return newRow2;
                };
                setData2((prevRows) => {
                  // Filter out duplicates based on routeCardId
                  const isDuplicate = prevRows.some(row => row.routeCardId === item1.routeCardId);
                  if (isDuplicate) {
                    return prevRows; // If duplicate, return the previous rows as is
                  }
                  
                  // If no duplicate, add the new row
                  return [...prevRows, createRow1()];
                });
              });

               
              
              setError("");
            }
            else {
              setData2([])
            }
            
          
          } catch (error) {
            setSpinnerL(true);
            setFieldValue("Routecard", null);
            setFieldValue("RoutecardId", null);
            setproflowname("");
            setproductname("");
            setproductid("");
            setqty("");
            setproductionordername("");
            setuomname("");
            setproductrevname("");
            setoperationname("");
            setoperationId("");
            setstatusnum(null);
            setdisable(true);
            setChildCount(false)
            setData1([])
            setData2([])
            setbase(null);
        setaddition(null);
        setside(null)
        setOrderShortageQty(null)
        setsequencecount(null)
        setMaxsequencecount(null)
        setOrderWIPQty(null)
         
            
            if (error.response.status === 401) {
              ErrorNotification("Session expired,Please login again");
            } else {
              ErrorNotification(error.response.data.errors[0]);
            }
          }
        }
      }
    }
    setSpinnerL(true);
  };

  const fetchDefectCodenGroup = async (OpId) => {
    try {
        const response = await getDegectCodeGroupId(+OpId);
        
        const res = response.data.value[0]?.DefectReasonGoupId;
        if (res) {
           
                const response = await getDefectCodeGroupDetailFetch(res);
                const result = response.data.value[0];
                const lists = result?.DefectCodeGroupEntries;
                if (lists?.length >= 1) {
                  const tempstore = lists.map((item) => ({
                      DefectCodeGroupEntryId: item?.DefectCodeGroupEntryId,
                      DefectCodeId: item?.DefectCodeId,
                      DefectCodeName: item?.DefectCode?.DefectCodeName,
                  }));
              
              setData(tempstore);
              setDefectReason(tempstore)
          }

        }
       
    
        else {
            setData([])
        }
        setError("");
    }
    catch (error) {
        setData([]);
        console.error("Error fetching data:", error);
        //setError("Error fetching data. Please check console for details.");
    }
};
  const handleTostepId = (event, newValue) => {
    setFieldValue("ToStep", newValue);
    if (!newValue) {
      setFieldValue("ToStepId", null);
    }
    const HoldreaId = tostepdata.find((r) =>
      r.nextStepName === newValue ? r.nextStepId : null
    );
    const { nextStepId } = HoldreaId;
    setFieldValue("ToStepId", nextStepId);
  };
  const handlescanroutecard1 = (event, newValue) => {
    setIsUsernameValid(true);
    setFieldValue("Routecard", newValue);
    setrows([]);
    if (newValue === null || newValue === "") {
      handleReset(event);
      setproductname("");
      setproductid("");
      setproflowname("");
      setqty("");
      setproductionordername("");
      setfactoryname("");
      setuomname("");
      setFieldValue("Routecard", null);
      setFieldValue("RoutecardId", null);
      setproductrevname("");
      setEquipment(null);
      setholdreamsgMsg(null);
      setoperationname("");
      setoperationId("");
      setstatusnum(null);
      setdisable(true);
      setDeleteData(null);
      setInrework(false);
      setFieldValue("Defects", false);
      setData([])
      setFieldValue("username", "");
      setFieldValue("EmployeeId", null);
      setChildCount(false)
      setData1([])
      setData2([])
      setbase(null);
        setaddition(null);
        setside(null)
        setOrderShortageQty(null)
        setsequencecount(null)
        setMaxsequencecount(null)
        setOrderWIPQty(null)
    } else {
      setproductname("");
      setproductid("");
      setproflowname("");
      setqty("");
      setproductionordername("");
      setfactoryname("");
      setuomname("");
      setproductrevname("");
      setEquipment(null);
      setholdreamsgMsg(null);
      setoperationname("");
      setoperationId("");
      setstatusnum(null);
      setdisable(true);
      setFieldValue("ToStep", null);
      setFieldValue("ToStepId", null);
      setDeleteData(null);
      setInrework(false);
      setData([])
      setFieldValue("Defects", false);
      setFieldValue("username", "");
      setFieldValue("EmployeeId", null);
      setChildCount(false)
      setData1([])
      setData2([])
      setbase(null);
        setaddition(null);
        setside(null)
        setOrderShortageQty(null)
        setsequencecount(null)
        setMaxsequencecount(null)
        setOrderWIPQty(null)
    }
  };
  const handlereset1 = () => {
    setrows([]);
    setproductname("");
    setproductid("");
    setproflowname("");
    setqty("");
    setproductionordername("");
    setfactoryname("");
    setuomname("");
    setFieldValue("Routecard", null);
    setFieldValue("Defects", false);
    setFieldValue("RoutecardId", null);
    setproductrevname("");
    setEquipment(null);
    setholdreamsgMsg(null);
    setoperationname("");
    setoperationId("");
    setstatusnum(null);
    setdisable(true);
    setDeleteData(null);
    setInrework(false);
    setData([])
    setFieldValue("username", "");
    setFieldValue("EmployeeId", null);
    setChildCount(false)
    setData1([])
    setData2([])
    handleReset(event);
    setbase(null);
        setaddition(null);
        setside(null)
        setOrderShortageQty(null)
        setsequencecount(null)
        setMaxsequencecount(null)
        setOrderWIPQty(null)
    setIsUsernameValid(true);
  };
  const handledocopen = () => {
    if (deleteData) {
      setisDocOpen(true);
    }
  };
  const handleWorkInfoopen = () => {
    if (deleteData) {
      setisWorkinfoOpen(true);
    }
  };
  
  const columns: GridColDef[] = [
    //{ field: "AqllevelId", headerName: "ID", width: 90 },
    {
      field: "DefectCodeName",
      headerName: "Reason",
      width: 250,
    },
    {
      field: "Qty",
      headerName: "Qty",
      width: 250,
      renderCell: (params) => {
        
        return (
          <MuiModules.UITextField
          name="Qty"
          id="Qty"
        type='number'
         
          value={params.value}
          onChange={handleMonthlyTargetValueChange(params)}
          onBlur={handleBlur}
          autoComplete="off"
        
          inputProps={{
            style: {
              padding: "0.3rem",
             
              
            },
            min:0,
          }}
          onKeyDown={(e) => {
            if (e.key === "-" || e.key === "e") {
              e.preventDefault();
            }
          }}
        />
          
        );
      },
    },
    
   
    // {
    //   field: "actions",
    //   headerName: "Action",
    //   type: "actions",
    //   width: 70,

    //   getActions: (params) => [
        
    //     <MuiModules.GridActionsCellItem
    //   icon={<MuiIcons.DeleteIcon />}
    //   label="Delete"
    //   //onClick={deleteCnfEquipment(params.id)}
    // />
    //   ],
    // },
  ];
  const handleMonthlyTargetValueChange=(params)=> (event) => {
    const { id, field } = params;
   
    const value1 = event.target.value;
    setData((rows) =>
      rows.map((row) => (row.DefectCodeGroupEntryId === id ? { ...row, [field]: value1 } : row))
    );
  };
  // const handleMonthlyTargetValueChange = (params) => (event) => {
    
  //   const { id, field } = params;
  //   let value = event.target.value;
  
  //   // Allow clearing the input (empty string)
  //  // if (value === "") {
  //     setData((rows) =>
  //       rows.map((row) => (row.DefectCodeGroupEntryId === id ? { ...row, [field]: value } : row))
  //     );
  //     return;
  //   //}
  
    // Validate the input value: check if it's a valid positive number (greater than 0)
    // if (/^\d+(\.\d+)?$/.test(value) && parseFloat(value) > 0) {
    //   // Only update the state if the value is a positive number
    //   setData((rows) =>
    //     rows.map((row) => (row.DefectCodeGroupEntryId === id ? { ...row, [field]: value } : row))
    //   );
    // }
//  };
  
 // const debouncedFetchUserdata = debounce(fetcUserdata1, 300);
  // const  handleBlurAndFetch = async (e) => {
  //  handleBlur(e); 

  //  //debouncedFetchUserdata(); 
  //    await fetcUserdata();
  // };

  const  handleBlurAndFetchroutecardsdata= async (row,id) => {
    //   handleBlur(e); 
  
      
    fetchRoutecard(row,id);
    };
    const fetchRoutecard = async (row,id) => {
      
      setSpinnerL(false);
      const Employename = row.trim();
      
      if (Employename == "") {
        
        setSpinnerL(true);
          return;
          
      }
      const body = {
        RouteCardId: values.RoutecardId,
        TxnName: "Disassociate",
      };
      try {
        
       // const response = await getScanCombineRouteCradGrid(body);
       const response = await getdisAssociateRouteCad(body);
          
              //const res = response.data.currentlyAssociatedRouteCards;
        
        const result = response.data.currentlyAssociatedRouteCards;
         
          if (result[0]) {
              
              
              const employeeData = result.find(employee => employee.routeCardName && employee.routeCardName.trim().toLowerCase() === row.toLowerCase());
              if(employeeData){
                setSpinnerL(true); 
                const isDuplicate = checkForDuplicate(employeeData.routeCardId,id);

                if (isDuplicate) {
                  ErrorNotification("Duplicate Unique Identification found, ");
                  resetRowValue(id); // Clear the row if duplicate found
                } else {
                  updateRowValue(id, employeeData?.routeCardId);
                }
                
               // updateRowValue(id, employeeData?.routeCardId);  
                
                
  
              }
             
              else{
                setSpinnerL(true);
                  ErrorNotification("Child Route Card Not Found");
                  resetRowValue(id); 
  
              }
              
          }
          else {
           
              setSpinnerL(true);
             ErrorNotification("Child Route Card Not Found");
              resetRowValue(id); 
          }
         
      }
      catch (error) {
          if (error.response.status === 401) {
          
              ErrorNotification("Session expired,Please login again");
          }
          else {
           
              ErrorNotification(error.response.data.errors[0]);
          }
          // if (error.response.status === 401) {
          //   ErrorNotification("Session expired,Please login again");
          // } 
          // else
          // {
          //   ErrorNotification(error.response.data);
          // }
          //ErrorNotification(error.message);
          setSpinnerL(true);
          resetRowValue(id); 
      }
      
  };
  // const checkForDuplicate1 = (employeeId) => {
  //   debugger
  //   const duplicate = Data1.some(row => row.UniqueIdentificationID === employeeId);
  //   return duplicate;
  // };
  const checkForDuplicate = (employeeId, currentId) => {
    // Check for duplicates, excluding the row with `currentId`
    const duplicate = Data1.some(row => row.UniqueIdentificationID === employeeId && row.UniqueId !== currentId);
    return duplicate;
  };
  const updateRowValue = (id, employeeId) => {
    
    setData1((prevRows) =>
      prevRows.map((row) =>
        row.UniqueId === id ? { ...row, UniqueIdentificationID: employeeId } : row  // Set the UniqueIdentificationID to employeeData.id
      )
    );
  };
  const resetRowValue = (id) => {
    
    setData1((prevRows) =>
      prevRows.map((row) => (row.UniqueId === id ? { ...row, UniqueIdentification: "",UniqueIdentificationID:null } : row))
    );
  };
//   const fetcUserdata = async () => {
//     setSpinnerL(false);
//     const Employename = values.username.trim();
    
//     if (Employename == "") {
//       setIsUsernameValid(true); 
//       setSpinnerL(true);
//         return;
        
//     }
    
//     try {
//         const response = await getEmployeeList();
       
//         if (response.data?.value[0]) {
//             const result = response.data.value;
            
//             const employeeData = result.find(employee => employee.EmployeeName && employee.EmployeeName.trim().toLowerCase() === values.username.toLowerCase());
//             if(employeeData){
//                 setFieldValue("EmployeeId", employeeData?.EmployeeId);
//                 setIsUsernameValid(true); 

//             }
//             else{
//                // ErrorNotification("User Name Not Found");
//                 setFieldValue("EmployeeId", null);
//                // setFieldValue("username", "");
//                setIsUsernameValid(false); 


//             }
            
//         }
//         else {
//         //  ErrorNotification("User Name Not Found");
//                 setFieldValue("EmployeeId", null);
//                // setFieldValue("username", "");
//                 setIsUsernameValid(false); 
//             setSpinnerL(true);
//         }
//         setSpinnerL(true);
//     }
//     catch (error) {
//       setFieldValue("EmployeeId", null);
//       setIsUsernameValid(false); 
//         if (error.response.status === 401) {
//             ErrorNotification("Session expired,Please login again");
//         }
//         else {
//             ErrorNotification(error.response.data.errors[0]);
//         }
//         // if (error.response.status === 401) {
//         //   ErrorNotification("Session expired,Please login again");
//         // } 
//         // else
//         // {
//         //   ErrorNotification(error.response.data);
//         // }
//         //ErrorNotification(error.message);
//         setSpinnerL(true);
//     }
// };
 
  
const columns1: GridColDef[] = [
       
    
  {
    field: "UniqueIdentification",
    headerName: "Unique Identification",
    width: 200,
    renderCell: (params) => {
      
      return (
        <MuiModules.UITextField
        name="UniqueIdentification"
        id="UniqueIdentification"
     
       
        value={params.value}
        onChange={handleqtychange(params)}
        onBlur={() => handleBlurAndFetchroutecardsdata(params.value, params.id)} // Pass the row value and ID on blur
        autoComplete="off"
      
        inputProps={{
          style: {
            padding: "0.3rem",
           
            
          },
        }}
      />
      );
    },
  },
  
  { field: 'DefectName', headerName: 'Reason', width: 250 ,
    renderCell: (params) => {
   
      return (
      
        <Autocomplete
          id="DefectName"
          fullWidth
          value={params.value}
          renderInput={(params) => (
            <MuiModules.UITextField
              {...params}
              size="small"
              //onClick={() => fetchoptionsmod(rows)}
            />
          )}
          options={DefectReason?.map(
            (item) => item.DefectCodeName
          )}
          onChange={handelcelledit(params)}
        />
      );
    },
  },
  
  {
    field: "actions",
    headerName: "Action",
    type: "actions",
    width: 80,
    getActions: (params) => [
      <MuiModules.GridActionsCellItem
        icon={<MuiIcons.DeleteIcon />}
        label="Delete"
        onClick={() => handleRemoveRow(params.id)}
      />,
    ],
  },
];


const columns2: GridColDef[] = [
       
    
  {
    field: "routeCardName",
    headerName: "Unique Identification",
    width: 250,
    
  },
  
  
  
    
  // {
  //   field: "Datacollection1",
  //   headerName: "Data Collection",
  //   type: "actions",
  //   width: 200,
     
  //   getActions: (params) => [
  //     <MuiModules.GridActionsCellItem
  //     icon={<MuiIcons.EditIcon />}
  //     label="Edit"
  //     onClick={edit(params)}
  //   />,       


    
  //   ],
  // },
  {
    field: "Datacollection1",
    headerName: "Data Collection",
    type: "actions",
    width: 250,
    getActions: (params) => [
      <MuiModules.GridActionsCellItem
        icon={<MuiIcons.EditIcon />}
        label="Edit"
        onClick={edit(params)}
      />,
    ],
  },
];
const edit = React.useCallback(
  
  (params) => () => {
    
    
    setSelectedRow(params.row);
    
    setoldrow(true);
  
    setopen1(true);
  },
  [Data2]
);
const handelcelledit = (params) => (event, newValue) => {
  const { id, field } = params;
  const value = newValue;
  const filteredValue = DefectReason.find(
    (item) => item.DefectCodeName === newValue
  );
  const Monthvalue = filteredValue ? filteredValue.DefectCodeId : null;
  setData1((prevRows) =>
    prevRows.map((row) =>
      row.UniqueId === id
        ? { ...row, [field]: value, DefectCodeId: Monthvalue }
        : row
    )
  );
  
};
const handleqtychange=(params)=> (event) => {
  const { id, field } = params;
 
  const value1 = event.target.value;
  setData1((rows) =>
    rows.map((row) => (row.UniqueId === id ? { ...row, [field]: value1 } : row))
  );
};
const handleAddButtonClick = () => {

  const newrow = {
    
    UniqueId: Math.random(),
    UniqueIdentification: "",
    DefectCodeId:null,
    DefectName:"",
    UniqueIdentificationID:null,
    
    
    
  }
  
setData1( [...Data1, newrow]);

};
const handleRemoveRow = (id) => {
  setData1((prevRows) =>
    prevRows.filter((row) => row.UniqueId !== id)
  );

  
  
};
const handleCloseEditPopup = () => {
  setSelectedRow(null);
   setopen1(false);
 };
 const updateDataCollection = (updatedRowData) => {
  setData2((prevData1) => 
    prevData1.map((group1) => {
      // Check if this group matches the EquipmentGroupEntryId
      if (group1.UniqueId === updatedRowData.values.UniqueId) {
        // Update the Datacollection for this group
        const updatedDatacollection = group1.Datacollection1.map((data1) => {
          // Check if the data entry should be updated (based on ID or any other logic)
          const updatedEntry = updatedRowData.rows1.find(row => row.id === data1.id);
          if (updatedEntry) {
            return {
              ...data1,
              ...updatedEntry, // Spread only the updated entry's values
            };
          }
          return data1; // Return unchanged data if no match found
        });

        return {
          ...group1,
          Datacollection1: updatedDatacollection, // Update the Datacollection
        };
      }
      return group1; // Return unchanged group
    })
  );
  handleCloseEditPopup();
};
useEffect(() => {
  // If rows.length > 0, open the Accordion, else keep it closed
  if (Data2.length >0) {
    setIsAccordionExpanded1(true); // Open Accordion if rows have data
  } else {
    setIsAccordionExpanded1(false); // Keep it closed if no rows
  }
}, [Data2]); 
const handleAccordionToggle = () => {
  setIsAccordionExpanded1((prev) => !prev);
};
const handleAccordionToggle1 = () => {
  setIsAccordionExpanded((prev) => !prev);
};
  return (
    <div
      className={`containerTransactions ${
        backgroundtheme === "black"
          ? "containerTransactions_Dark"
          : "containerTransactions"
      }`}
    >
      <form onSubmit={handleSubmit} onReset={handleReset}>
        {error && <p style={{ color: "red" }}>{error}</p>}
        {msg && <p style={{ color: "green" }}>{msg}</p>}
        <Backdrop className="backdrop" open={!spinnerL}>
          <CircularProgress color="inherit" />
        </Backdrop>
        <Backdrop className="backdrop" open={submitspinnerL}>
          <CircularProgress color="inherit" />
        </Backdrop>
        <MuiModules.UIGrid
          container
          rowSpacing={1}
          columnSpacing={{ xs: 2, sm: 2, md: 3 }}
          className="headerTransaction"
        >
          <MuiModules.UIGrid
            item
            xs={12}
            sm={12}
            md={8}
            style={{ display: "flex", alignItems: "center", gap: "4px" }}
          >
            <label htmlFor="routeCard">
              <h3>RouteCard:</h3>
            </label>
            <MuiModules.UIAutocomplete
              disablePortal
              id="Routecard"
              options={routecarddata.map((item) => item.RouteCardName)}
              renderInput={(params) => (
                <MuiModules.UITextField
                  {...params}
                  onBlur={(event) => {
                    handlescanroutecard(event, event.target.value);
                  }}
                />
              )}
              onChange={(event, newValue) => {
                handlescanroutecard1(event, newValue);
              }}
              style={{ width: "300px" }}
              value={values.Routecard}
              onOpen={() => {
                setOpen(true);
              }}
              loading={open && routecarddata.length === 0}
            />
            {/* {errors.routeCard && touched.routeCard ? (
              <p className="errorTextColor">{errors.routeCard}</p>
            ) : null} */}
            <label
              htmlFor="Status"
              style={{ marginLeft: "1.5rem", marginRight: "5px" }}
            >
              <h3>Status:</h3>
            </label>
            {statusnum === 0 && (
              <>
                <div className="statusboxHold"></div>
                <span
                  style={{
                    color: backgroundtheme === "black" ? "white" : "black",
                  }}
                >
                  Delete
                </span>
              </>
            )}
            {statusnum === 1 && (
              <>
                <div className="statusbox"></div>
                <span
                  style={{
                    color: backgroundtheme === "black" ? "white" : "black",
                  }}
                >
                  Active
                </span>
              </>
            )}
            {statusnum === 2 && (
              <>
                <div className="statusboxClosed"></div>
                <span
                  style={{
                    color: backgroundtheme === "black" ? "white" : "black",
                  }}
                >
                  Closed
                </span>
              </>
            )}
            {statusnum === 3 && (
              <>
                <div className="statusboxHold"></div>
                <span
                  style={{
                    color: backgroundtheme === "black" ? "white" : "black",
                  }}
                >
                  Hold
                </span>
              </>
            )}
            {statusnum === 4 && (
              <>
                {/* <div className="statusboxHold"></div> */}
                <span
                  style={{
                    color: backgroundtheme === "black" ? "white" : "black",
                  }}
                >
                  Active
                </span>
              </>
            )}
            {statusnum === 5 && (
              <>
                {/* <div className="statusboxHold"></div> */}
                <span
                  style={{
                    color: backgroundtheme === "black" ? "white" : "black",
                  }}
                >
                  Active
                </span>
              </>
            )}
            {statusnum === 6 && (
              <>
                {/* <div className="statusboxHold"></div> */}
                <span
                  style={{
                    color: backgroundtheme === "black" ? "white" : "black",
                  }}
                >
                  Active
                </span>
              </>
            )}

{Inrework&& (
          <MuiModules.UIGrid
            item
            xs={12}
            sm={12}
            md={4}
            style={{
              marginLeft: "2rem",
            }}
          >
            <span
                  style={{
                    color: "red", fontWeight: "bold",
                  }}
                >
                  In Rework
                </span>
          </MuiModules.UIGrid>
           )}
          </MuiModules.UIGrid>
         
          <MuiModules.UIGrid
            item
            xs={12}
            sm={12}
            md={4}
            style={{
              paddingRight: "2rem",
            }}
          >
            <span onClick={handledocopen}>
              <DescriptionIcon style={{ fontSize: "30px" }} />
            </span>
            <span onClick={handleWorkInfoopen} style={{ marginLeft: "15px" }}>
              <InfoIcon style={{ fontSize: "30px" }} />
            </span>
            <h2 style={{ float: "right" }}>Move</h2>
          </MuiModules.UIGrid>
        </MuiModules.UIGrid>

        <div className="routeCardFeatures">
          <MuiModules.UIGrid
            container
            rowSpacing={1}
            columnSpacing={{ xs: 2, sm: 2, md: 3 }}
          >
            <MuiModules.UIGrid item xs={12} sm={12} md={4} className="features">
              <h4>Lens Type:</h4>
              <p 
            style={{
              whiteSpace: 'nowrap', 
              overflow: 'hidden', 
              textOverflow: 'ellipsis', 
              marginRight: '10px', 
              display: 'inline-block', 
              maxWidth: '200px' // Set max width if you want to control text overflow
            }}
          >
            {productname}
          </p>
              {/* <p 
  style={{
    whiteSpace: 'nowrap',
    overflow: 'hidden',
    textOverflow: 'ellipsis'
  }} 
  title={productname ? `${productname}(${productrevname})` : ''}
>
  {productname ? `${productname}(${productrevname})` : null}
</p> */}
            </MuiModules.UIGrid>
            <MuiModules.UIGrid item xs={12} sm={12} md={4} className="features">
              <h4>Qty:</h4>
              <p>{qty}</p>
            </MuiModules.UIGrid>
            <MuiModules.UIGrid item xs={12} sm={12} md={4} className="features">
              <h4>Production Order:</h4>
              <p>{productionordername}</p>
            </MuiModules.UIGrid>
            <MuiModules.UIGrid item xs={12} sm={12} md={4} className="features">
              <h4>Operation:</h4>
              <Tooltip title={`${operationname ? `${operationname} (${sequencecount}/${Maxsequencecount})` : ''}`} arrow>
          <p 
            style={{
             whiteSpace: 'nowrap', 
             overflow: 'hidden', 
              textOverflow: 'ellipsis', 
              marginRight: '10px', 
              display: 'inline-block', 
              maxWidth: '350px' 
              
            }}
          >
           {operationname && sequencecount !== undefined && Maxsequencecount !== undefined 
        ? `${operationname} (${sequencecount}/${Maxsequencecount})`
        : (operationname === null || sequencecount === null || Maxsequencecount === null 
            ? ""  // Show empty string if any of them are null or undefined
            : `${sequencecount}`) // Else just show the sequence count
      }
          </p> 
        </Tooltip>
        
           
            </MuiModules.UIGrid>
            <MuiModules.UIGrid item xs={12} sm={12} md={4} className="features">
              <h4>Process Flow:</h4>
              <p>{proflowname ? `${proflowname}(${proflowrevname})` : null}</p>
            </MuiModules.UIGrid>
            <MuiModules.UIGrid item xs={12} sm={12} md={4} className="features">
              <h4>Customer:</h4>
              <Tooltip title={uomname} arrow>
          <p 
            style={{
             whiteSpace: 'nowrap', 
             overflow: 'hidden', 
              textOverflow: 'ellipsis', 
              marginRight: '10px', 
              display: 'inline-block', 
              maxWidth: '350px' 
              
            }}
          >
          {uomname}
          </p> 
        </Tooltip>
             
            </MuiModules.UIGrid>
            <MuiModules.UIGrid item xs={12} sm={12} md={4} className="features">
              <h4>Order Shortage Qty:</h4>
              <p> {OrderShortageQty}</p>
              
            
            </MuiModules.UIGrid>
            <MuiModules.UIGrid item xs={12} sm={12} md={4} className="features">
              <h4>  Order WIP Qty:</h4>
              <p> {OrderWIPQty}</p>
              
            
            </MuiModules.UIGrid>
          
            <MuiModules.UIGrid item xs={12} sm={12} md={4} className="features">
              <h4>Base:</h4>
              <p> {base}</p>
            </MuiModules.UIGrid>
            <MuiModules.UIGrid item xs={12} sm={12} md={4} className="features">
              <h4>Addition:</h4>
              <p> {addition}</p>
            </MuiModules.UIGrid>
            
            <MuiModules.UIGrid item xs={12} sm={12} md={4} className="features">
              <h4>Side:</h4>
              <p> {side}</p>
            </MuiModules.UIGrid>
          </MuiModules.UIGrid>
        </div>

        <div className="subcontainer">
          <MuiModules.UIGrid
            container
            rowSpacing={1}
            columnSpacing={{ xs: 2, sm: 2, md: 3 }}
            mt={2}
            mb={2}
          >
            <MuiModules.UIGrid
              item
              xs={12}
              sm={12}
              md={4}
              style={{ display: "flex", flexDirection: "column" }}
            >
              <label style={{ fontSize: "14px" }}>
                Equipment
                {/* <span style={{ color: "red" }}>*</span> */}
              </label>
              <MuiModules.UIAutocomplete
                disablePortal
                id="Equipment"
                options={
                  values.RoutecardId
                    ? loadequipdata.map(
                        (item) => item?.EquipmentName
                      )
                    : demodata
                }
                renderInput={(params) => (
                  <MuiModules.UITextField
                    {...params}
                    //
                    size="small"
                  />
                )}
                // onChange={(event, newValue) => {
                //   handleEquipment(event, newValue);
                // }}
                onChange={(event, newValue) => {
                  handleHoldReason(event, newValue);
                }}
                value={Equipment}
              />
              {holdreamsg && holdreamsg ? (
                <p className="errorTextColor">{holdreamsg}</p>
              ) : null}
            </MuiModules.UIGrid>
            <MuiModules.UIGrid
              item
              xs={12}
              sm={12}
              md={4}
              style={{ display: "flex", flexDirection: "column" }}
            >
              <label style={{ fontSize: "14px" }}>
                To Step
                {/* <span style={{ color: "red" }}>*</span> */}
              </label>
              <MuiModules.UIAutocomplete
                disablePortal
                id="ToStep"
                options={
                  values.RoutecardId
                    ? tostepdata.map((item: any) => item.nextStepName)
                    : demodata
                }
                renderInput={(params) => (
                  <MuiModules.UITextField
                    {...params}
                    //
                    size="small"
                  />
                )}
                onChange={(event, newValue) => {
                  handleTostepId(event, newValue);
                }}
                value={values.ToStep}
              />
            </MuiModules.UIGrid>
            <MuiModules.UIGrid
                item
                xs={12}
                sm={12}
                md={4}
                style={{ display: "flex", flexDirection: "column" }}
              >
                <label htmlFor="username">User Name</label>
                <MuiModules.UITextField
                  name="username"
                  id="username"
                  value={values.username}
                  onChange={handleUsernameChange}
                // onBlur={handleBlurAndFetch}
                  disabled={disable}
                 autoComplete="off"
                  InputProps={{
                    style: {
                      outline: "none", // Remove the default outline
                      boxShadow: "none", // Remove any shadow effect
                    },
                  }}
                  sx={{
                    "& .MuiOutlinedInput-root.Mui-focused": {
                      borderColor: "transparent", // Remove the blue border
                      boxShadow: "none", // Remove focus shadow
                    },
                  }}
                />
                     {(!isUsernameValid || (errors.username && touched.username)) && (
    <p className="errorTextColor">
      {isUsernameValid ? errors.username : "User Name is Invalid"}
    </p>
  )}
              </MuiModules.UIGrid>
            <MuiModules.UIGrid
            item
            xs={12}
            sm={12}
            md={4}
            style={{
              display: "flex",
              justifyContent: "flex-start",
              alignItems: "center",
              marginTop: "1rem",
            }}
          >
            <Checkbox
              name="Defects"
              onChange={handleChange}
              checked={values.Defects}
            />
            <label style={{ fontSize: "14px" }}>Defects Identified</label>
          </MuiModules.UIGrid>
            
          </MuiModules.UIGrid>
          {values.Defects && !ChildCount && (
          <MuiModules.UIBox
          sx={{
            width:"150vh",
         //   transition: "width 0.3s",
            marginTop: "5px",
            marginLeft:"15px"
          }}
        >
            <GridPro rows={Data} columns={columns}  id="DefectCodeGroupEntryId"/>
        </MuiModules.UIBox>
          )}
           {values.Defects && ChildCount &&(
          <div>
            <h4 style={{ marginTop: "15px", marginBottom: "2px" }}>
            UNIQUE IDENTIFICATION DETAILS:
          </h4>
          <div style={{ marginRight: "20px", marginTop: "5px" }}>
            <MuiModules.UIButton
              variant="contained"
              color="primary"
              onClick={handleAddButtonClick}
            >
              Add
            </MuiModules.UIButton>
          </div>
          <Box
            sx={{
              width: "150vh" ,
              transition: "width 0.3s",
              marginTop: "5px",
            }}
          >
            <GridPro1
              rows={Data1}
              columns={columns1}
              id="UniqueId"
              paginationModel={paginationModel}
              onPaginationModelChange={setPaginationModel}
            />
          </Box>
          </div>
          )}
          {rows.length > 0 && (
            <>
              {Data2.length !== 0 ? (
                
                 <>
            <Accordion   expanded={isAccordionExpanded1}style={{ marginTop: "10px" }}>
            <AccordionSummary
              expandIcon={<ExpandMoreIcon />}
              aria-controls="panel1-content"
              id="panel1-header"
              onClick={handleAccordionToggle}
            >
              Data Collection
            </AccordionSummary>
            <AccordionDetails>
            <Box
            sx={{
              width: "150vh" ,
              transition: "width 0.3s",
              marginTop: "5px",
            }}
          >
            <GridPro1
              rows={Data2}
              columns={columns2}
              id="UniqueId"
              paginationModel={paginationModel}
              onPaginationModelChange={setPaginationModel}
            />
          </Box>
             
            </AccordionDetails>
          </Accordion>
          </>
                 
        ):(
          <>
          <Accordion  expanded={isAccordionExpanded} style={{ marginTop: "10px" }}>
            <AccordionSummary
              expandIcon={<ExpandMoreIcon />}
              aria-controls="panel1-content"
              id="panel1-header"
             onClick={handleAccordionToggle1}
            >
            <span>Data Collection -  {rows[0]?.dataCollectionName}</span>
            </AccordionSummary>
            <AccordionDetails>
            <DataCollectAccor2
              rows={rows}
              setrows={setrows}
              onSelect={(id) => setselecteddataId(id)}
            />
           
           </AccordionDetails>
          </Accordion>
          </>
           
           )}
          </>
          )}
         
          <Accordion style={{ marginTop: "10px" }}>
            <AccordionSummary
              expandIcon={<ExpandMoreIcon />}
              aria-controls="panel1-content"
              id="panel1-header"
            >
              Additional fields
            </AccordionSummary>
            <AccordionDetails>
              <MuiModules.UIGrid
                item
                xs={12}
                sm={12}
                md={8}
                style={{ display: "flex", flexDirection: "column" }}
              >
                <label htmlFor="Comments">Comments</label>
                <MuiModules.UITextField
                  name="Comments"
                  id="Comments"
                  value={values.Comments}
                  onChange={handleChange}
                  multiline
                  maxRows={4}
                  inputProps={{
                    maxLength: 250,
                  }}
                />
              </MuiModules.UIGrid>
            </AccordionDetails>
          </Accordion>
        </div>

        <div
          className={`actionFooter ${
            backgroundtheme === "black" ? "actionFooter_Dark" : "actionFooter"
          }`}
        >
          <Copyright />
          <MuiModules.UIButton
            variant="outlined"
            size="small"
            color="primary"
            type="reset"
            onClick={handlereset1}
          >
            Reset
          </MuiModules.UIButton>
          &nbsp; &nbsp;
          {Execute && (
            <MuiModules.UIButton
              variant="contained"
              size="small"
              color="primary"
              type="submit"
              disabled={disable}
            >
              Submit
            </MuiModules.UIButton>
          )}
        </div>
      </form>
      {isDocOpen && deleteData && (
        <ConfirmDialog
          isOpen={isDocOpen}
          onClose={docclose}
          data={deleteData}
          //onDelete={OnCallAPI}
          screenName="Move"
          // valueName={deleteDataName}
        />
      )}

      {isWorkinfoOpen && deleteData && (
        <WorkInfoDialog
          isOpen={isWorkinfoOpen}
          onClose={WorkinfoClose}
          data={deleteData}
          //onDelete={OnCallAPI}
          screenName="Move"
          // valueName={deleteDataName}
          operationId={operationId}
          productid={productid}
        />
      )}
       <DataCollectionPopUp
        open={open1}
        onClose={handleCloseEditPopup}
        selectedRow={selectedRow}
        onSave={(updatedRowData1) => {
          updateDataCollection(updatedRowData1); // Update the grid data collection
          //handleCloseEditPopup(); // Close the popup after saving
        }}
        isEdit={isoldrow}
      /> 
    </div>
  );
};

export default Move;
